# SECURITY AND RELEASE CHECKLIST

Use this checklist before publishing `@_ns/strapi-plugin-mega-menu`.

## 1) Secret Hygiene (Blocker)

- [ ] Confirm `.env` is never included in plugin package (already excluded by `files` in plugin `package.json`).
- [ ] Rotate any previously exposed secrets:
  - [ ] `APP_KEYS`
  - [ ] `API_TOKEN_SALT`
  - [ ] `ADMIN_JWT_SECRET`
  - [ ] `TRANSFER_TOKEN_SALT`
  - [ ] `ENCRYPTION_KEY`
  - [ ] `JWT_SECRET`
  - [ ] Database password and credentials
- [ ] Verify project root `.gitignore` contains `.env`.
- [ ] If secrets were ever pushed to a remote, rotate immediately and invalidate old credentials.

## 2) Dependency Security (Blocker)

- [ ] Run `npm audit --omit=dev` at project root.
- [ ] Record unresolved vulnerabilities and why they are acceptable (if they come from pinned Strapi transitive deps).
- [ ] Prefer updating to latest safe Strapi v5 patch versions before release.
- [ ] Do **not** use `npm audit fix --force` without validating Strapi version compatibility.

## 3) Functional Validation (Required)

- [ ] Run `npm run build` at project root.
- [ ] Start app and verify plugin loads in admin.
- [ ] Manual smoke tests:
  - [ ] Create menu item
  - [ ] Update menu item
  - [ ] Delete menu item
  - [ ] Reorder using drag-drop
  - [ ] Validate max depth enforcement
  - [ ] Validate URL and title constraints
- [ ] Confirm custom field `mega-menu-builder` works in a content type.

## 4) Package Readiness (Required)

- [ ] Run `npm publish --dry-run` in `src/plugins/mega-menu`.
- [ ] Confirm tarball includes only expected files:
  - [ ] `admin/`
  - [ ] `server/`
  - [ ] `strapi-server.js`
  - [ ] `README.md`
  - [ ] `LICENSE`
- [ ] Confirm package metadata is correct:
  - [ ] name/version
  - [ ] description/keywords
  - [ ] license
  - [ ] peer dependency (`@strapi/strapi`)

## 5) Docs and Versioning (Required)

- [ ] Ensure plugin `README.md` has install, usage, API endpoints, and constraints.
- [ ] Bump version in `src/plugins/mega-menu/package.json` for each release.
- [ ] Add release notes (recommended) with fixes and known limitations.

## 6) Final Go/No-Go Gate

Release only if all conditions are true:

- [ ] No exposed active secrets
- [ ] Build succeeds
- [ ] Core flows pass smoke test
- [ ] Dry-run publish output is clean
- [ ] Security risk is documented and accepted

## Suggested Release Commands

```bash
# from project root
npm run build

# from plugin directory
cd src/plugins/mega-menu
npm publish --dry-run
```
