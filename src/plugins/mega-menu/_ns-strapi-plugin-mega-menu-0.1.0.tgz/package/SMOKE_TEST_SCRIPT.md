# Mega Menu Plugin Smoke Test Script

Run this before release to validate critical flows quickly.

## Pre-check

- [ ] `npm run build` passes
- [ ] Strapi app starts without plugin errors
- [ ] Admin panel opens and `Mega Menu` plugin page is visible

## A) Plugin Admin Page Flow (`/admin/plugins/mega-menu`)

### 1) Create Items

- [ ] Create root item: `Home`, URL `/`
- [ ] Create root item: `Products`, URL `/products`
- [ ] Create child under `Products`: `Laptops`, URL `/products/laptops`
- [ ] Create nested child under `Laptops`: `Gaming`, URL `/products/laptops/gaming`
- [ ] Verify success toasts and rows appear in table

### 2) Edit Item

- [ ] Edit `Gaming` -> title `Gaming Laptops`
- [ ] Change URL to `/products/laptops/gaming-laptops`
- [ ] Save and verify table updates

### 3) Delete Item

- [ ] Delete one non-root item (e.g. `Home` or any leaf)
- [ ] Confirm delete modal works and row is removed

### 4) Reorder / Drag-Drop

- [ ] Drag one root item above/below another root item
- [ ] Drag one item into another item (inside drop zone)
- [ ] Verify order and hierarchy update persist after reload

### 5) Max Depth Guard

- [ ] Set max depth to `2`
- [ ] Try to place a node beyond level 2
- [ ] Verify warning is shown and invalid move is blocked

## B) Custom Field Flow (`mega-menu-builder`)

### 1) Attach field to a content type

- [ ] Open Content-Type Builder
- [ ] Add custom field `Mega Menu Builder` to one collection type
- [ ] Save and restart if required by Strapi

### 2) Field Interactions

- [ ] Create 2 root entries in the field
- [ ] Create nested child entries
- [ ] Collapse/Expand all works
- [ ] Drag-drop works inside field editor
- [ ] Save entry and reopen
- [ ] Data persists without shape corruption

### 3) Validation Cases

- [ ] Create/update with empty title -> blocked
- [ ] Create/update with empty URL -> blocked
- [ ] Invalid URL (e.g. `javascript:alert(1)`) -> blocked
- [ ] Valid absolute URL (`https://example.com`) -> accepted
- [ ] Valid relative URL (`/contact`) -> accepted

## C) API Quick Validation (Admin authenticated)

Use browser network tab or API client with admin auth.

- [ ] `GET /mega-menu/items` returns list
- [ ] `POST /mega-menu/items` creates item with valid payload
- [ ] `PUT /mega-menu/items/:id` updates item
- [ ] `PUT /mega-menu/items/reorder` accepts valid reorder payload
- [ ] `DELETE /mega-menu/items/:id` deletes item
- [ ] Invalid payload returns `400` with clear message

## D) Regression Checks

- [ ] Reload admin and verify no blank state bugs
- [ ] No console runtime errors in browser devtools
- [ ] Drag-drop still works after multiple edits/deletes
- [ ] Build still passes after test cycle

## E) Final Sign-off

Release candidate is ready when all are true:

- [ ] All sections A-D pass
- [ ] `npm publish --dry-run` is clean
- [ ] Security checklist is complete

---

## Suggested evidence to keep (for reviewer confidence)

- Screenshot of plugin page with nested items
- Screenshot of custom field editor tree
- 1-2 API response samples for create/reorder
- Build and dry-run command outputs
